function Contact() {
  return <h1>Contact component</h1>;
}

export default Contact;
