function Home() {
  return <h1>Home component</h1>;
}

export default Home;
